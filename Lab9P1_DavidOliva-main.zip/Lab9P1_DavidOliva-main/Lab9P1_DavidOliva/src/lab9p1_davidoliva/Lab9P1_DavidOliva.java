package lab9p1_davidoliva;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author DAVIDANDRESOLIVAHERN
 */
public class Lab9P1_DavidOliva {

    /**
     * @param args the command line arguments
     */
    private static Scanner leer = new Scanner(System.in);
    private static Scanner lea = new Scanner(System.in);

    public static void main(String[] args) {
        int opc = 0;
        do {
            System.out.println("-----------------------------------------------------------------------");
            System.out.println("|                                  MENU                               | ");
            System.out.println("-----------------------------------------------------------------------");
            System.out.println("| 1. Palíndromo Recursivo           |" + " 2. Palabra más recurrente       |");
            System.out.println("| 3. Batalla Pokemon                |" + " 4. Salir                        |");
            System.out.println("-----------------------------------------------------------------------");
            System.out.print("Ingrese una Opcion ( 1,2,3,4 ):");
            opc = lea.nextInt();
            switch (opc) {
                case 1 -> {
                    Palindromo palindromo = new Palindromo();
                    palindromo.generarArraylist();
                    palindromo.mostrarArraylist();
                    if (palindromo.DetPalindromo()) {
                        System.out.println("\n" + "Es palindromo");
                    } else {
                        System.out.println("\n" + "No es palindromo");
                    }
                }
                case 2 -> {
                    Random random = new Random();
                    int size = random.nextInt(3) + 3; 
                    System.out.println("El random es: " + size);
                    ArrayList<String> palabras = new ArrayList<>();
                    Scanner scanner = new Scanner(System.in);
                    for (int i = 1; i <= size; i++) {
                        System.out.print(i + ". Ingrese palabra: ");
                        palabras.add(scanner.nextLine());
                    }
                    Conteo conteo = new Conteo(palabras);
                    conteo.ContLetras();
                }
                case 3 -> {

                }
            }
        } while (opc != 4);

    }
}
