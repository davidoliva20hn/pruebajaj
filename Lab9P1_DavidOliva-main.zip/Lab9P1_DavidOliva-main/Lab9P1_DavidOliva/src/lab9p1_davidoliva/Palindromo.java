/*
 */
package lab9p1_davidoliva;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author DAVIDANDRESOLIVAHERN
 */
public class Palindromo {

    public static ArrayList<Integer> arrayList = new ArrayList<>();
    Scanner lea = new Scanner(System.in);
    public Palindromo() {
        
    }

    public void generarArraylist() {
        Random random = new Random();
        int size = random.nextInt(8) + 3; 
        System.out.println("Su random es: " + size);
     ArraylistRecu(size);
    }

    public void ArraylistRecu(int rest) {
        if (rest > 0) {
            System.out.print(rest + ". Ingrese numero: ");
            int num = lea.nextInt();
            arrayList.add(num);
            ArraylistRecu(rest - 1);
        }
    }

    public void mostrarArraylist() {
        ImprimirArraylistRecu(0);
        System.out.println();
    }

    public void ImprimirArraylistRecu(int index) {
        if (index < arrayList.size()) {
            System.out.print(arrayList.get(index) + " ");
            ImprimirArraylistRecu(index + 1);
        }
    }

    public boolean DetPalindromo() {
        return Palindromo(0, arrayList.size() - 1);
    }

    public boolean Palindromo(int menor, int mayor) {
        if (menor>= mayor) {
            return true; 
        }
        if (arrayList.get(menor).equals(arrayList.get(mayor))) {
            return Palindromo(menor + 1, mayor - 1);
        } else {
            return false; 
        }
    }

}
