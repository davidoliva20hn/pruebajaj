package lab9p1_davidoliva;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author DAVIDANDRESOLIVAHERN
 */
public class Conteo {

    private ArrayList<String> palabras;

    public Conteo(ArrayList<String> palabras) {
        this.palabras = palabras;
    }

    public void ContLetras() {
        for (String palabra : palabras) {
            System.out.println();
            System.out.println("Palabra: " + palabra);
            ContarPalabra(palabra);
        }
    }

    public void ContarPalabra(String palabra) {
        int[] frecuLetras = new int[26];
        palabra = palabra.replace(" ", "").toLowerCase();
        for (char letra : palabra.toCharArray()) {
            if (Character.isLetter(letra)) {
                frecuLetras[letra - 'a']++;
                
            }
        }
        char letraRecur = 0;
        int maxFrec = 0;
        boolean emp = false;
        for (int i = 0; i < frecuLetras.length; i++) {
            char letra = (char) ('a' + i);
            int frecu = frecuLetras[i];
            if (frecu > maxFrec) {
                letraRecur= letra;
                maxFrec = frecu;
                emp = false;
            } else if (frecu == maxFrec) {
                emp = true;
            }
        }

        for (int i = 0; i < frecuLetras.length; i++) {
            char letra = (char) ('a' + i);
            for (int j = 0; j < palabra.length(); j++) {
                char pala = palabra.charAt(j);
                if (pala == letra) {
                    System.out.println(letra + ": " + frecuLetras[i]);
                }
            }
        }
        if (emp || maxFrec == 1) {
            System.out.println("No hay una única letra más recurrente");
        } else {
            System.out.println("Letra más recurrente es la '" + letraRecur + "', aparece " + maxFrec + " veces");
        }
    }
}
