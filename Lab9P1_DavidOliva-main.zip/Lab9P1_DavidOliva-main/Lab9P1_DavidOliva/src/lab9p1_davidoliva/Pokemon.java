
package lab9p1_davidoliva;

/**
 *
 * @author DAVIDANDRESOLIVAHERN
 */
public class Pokemon {
    
}
